-- MySQL dump 10.13  Distrib 8.0.24, for Linux (x86_64)
--
-- Host: localhost    Database: wuzhe
-- ------------------------------------------------------
-- Server version	8.0.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sequelizemeta`
--

DROP TABLE IF EXISTS `sequelizemeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequelizemeta` (
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`name`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequelizemeta`
--

LOCK TABLES `sequelizemeta` WRITE;
/*!40000 ALTER TABLE `sequelizemeta` DISABLE KEYS */;
/*!40000 ALTER TABLE `sequelizemeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_bag`
--

DROP TABLE IF EXISTS `user_bag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_bag` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int DEFAULT NULL,
  `道具` json DEFAULT NULL,
  `功法` json DEFAULT NULL,
  `已学习功法` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_bag`
--

LOCK TABLES `user_bag` WRITE;
/*!40000 ALTER TABLE `user_bag` DISABLE KEYS */;
INSERT INTO `user_bag` VALUES (25,100000000,'[]','[]','[]');
/*!40000 ALTER TABLE `user_bag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_equiment`
--

DROP TABLE IF EXISTS `user_equiment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_equiment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int DEFAULT NULL,
  `武器` json DEFAULT NULL,
  `胸甲` json DEFAULT NULL,
  `腿甲` json DEFAULT NULL,
  `法宝` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_equiment`
--

LOCK TABLES `user_equiment` WRITE;
/*!40000 ALTER TABLE `user_equiment` DISABLE KEYS */;
INSERT INTO `user_equiment` VALUES (31,100000000,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `user_equiment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_id`
--

DROP TABLE IF EXISTS `user_id`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_id` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int DEFAULT NULL,
  `绑定账号` json DEFAULT NULL,
  `允许绑定账号` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_id`
--

LOCK TABLES `user_id` WRITE;
/*!40000 ALTER TABLE `user_id` DISABLE KEYS */;
INSERT INTO `user_id` VALUES (30,100000000,'[\"2325982808686709907\"]','[\"2325982808686709907\"]');
/*!40000 ALTER TABLE `user_id` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_player`
--

DROP TABLE IF EXISTS `user_player`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_player` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int DEFAULT NULL,
  `name` json DEFAULT NULL,
  `性别` json DEFAULT NULL,
  `宣言` json DEFAULT NULL,
  `语言包` json DEFAULT NULL,
  `武者境界` json DEFAULT NULL,
  `体魄境界` json DEFAULT NULL,
  `灵魂境界` json DEFAULT NULL,
  `灵气` json DEFAULT NULL,
  `体魄力量` json DEFAULT NULL,
  `灵魂力量` json DEFAULT NULL,
  `攻击加成` json DEFAULT NULL,
  `防御加成` json DEFAULT NULL,
  `暴击加成` json DEFAULT NULL,
  `爆伤加成` json DEFAULT NULL,
  `生命加成` json DEFAULT NULL,
  `闪避加成` json DEFAULT NULL,
  `当前生命` json DEFAULT NULL,
  `生命上限` json DEFAULT NULL,
  `金钱` json DEFAULT NULL,
  `本命灵器` json DEFAULT NULL,
  `武者认证` json DEFAULT NULL,
  `技能栏` json DEFAULT NULL,
  `宗门` json DEFAULT NULL,
  `猎妖目标` json DEFAULT NULL,
  `体质` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_player`
--

LOCK TABLES `user_player` WRITE;
/*!40000 ALTER TABLE `user_player` DISABLE KEYS */;
INSERT INTO `user_player` VALUES (24,100000000,'\"名字\"','\"/踏入武者\"','\"无\"',NULL,'\"F阶低级武者\"','\"体魄一重天\"','\"灵魂境界一重天\"','0','0','0','100','100','0.01','0.01','100','0','1000','1000','1000','{\"id\": 41, \"exp\": 0, \"name\": \"狂暴之戟\", \"品级\": \"中级灵器\", \"等级\": 1, \"攻击加成\": 50, \"暴击加成\": 0.02, \"爆伤加成\": 0.03, \"生命加成\": 35, \"闪避加成\": 0.03, \"防御加成\": 25}','\"无\"','{\"技能栏1\": \"无\", \"技能栏2\": \"无\", \"技能栏3\": \"无\", \"技能栏4\": \"无\", \"技能栏5\": \"无\"}',NULL,NULL,'\"无\"');
/*!40000 ALTER TABLE `user_player` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_status`
--

DROP TABLE IF EXISTS `user_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_status` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int DEFAULT NULL,
  `打工` json DEFAULT NULL,
  `修炼` json DEFAULT NULL,
  `锻炼` json DEFAULT NULL,
  `修炼灵魂` json DEFAULT NULL,
  `猎杀妖兽` json DEFAULT NULL,
  `猎妖` json DEFAULT NULL,
  `采药` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_status`
--

LOCK TABLES `user_status` WRITE;
/*!40000 ALTER TABLE `user_status` DISABLE KEYS */;
INSERT INTO `user_status` VALUES (26,100000000,'0','0','0','0','0','0','0');
/*!40000 ALTER TABLE `user_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_zongmen`
--

DROP TABLE IF EXISTS `user_zongmen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_zongmen` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `宗主` int DEFAULT NULL,
  `钱库` json DEFAULT NULL,
  `宗门等级` json DEFAULT NULL,
  `副宗主` json DEFAULT NULL,
  `长老` json DEFAULT NULL,
  `成员` json DEFAULT NULL,
  `修炼加成` json DEFAULT NULL,
  `加入最高境界` varchar(255) COLLATE utf8mb4_general_ci DEFAULT '无',
  `加入最低境界` varchar(255) COLLATE utf8mb4_general_ci DEFAULT '无',
  `建立时间` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `宗门阵法石` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_zongmen`
--

LOCK TABLES `user_zongmen` WRITE;
/*!40000 ALTER TABLE `user_zongmen` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_zongmen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `丹方`
--

DROP TABLE IF EXISTS `丹方`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `丹方` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `材料` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `丹方`
--

LOCK TABLES `丹方` WRITE;
/*!40000 ALTER TABLE `丹方` DISABLE KEYS */;
INSERT INTO `丹方` VALUES (1,'高级聚神丹','[{\"name\": \"灵动花瓣\", \"数量\": 20}, {\"name\": \"聚神果\", \"数量\": 8}]'),(2,'低级强灵丹','[{\"name\": \"低级强灵草\", \"数量\": 10}]'),(3,'中级聚神丹','[{\"name\": \"灵动花瓣\", \"数量\": 15}, {\"name\": \"聚神果\", \"数量\": 4}]'),(4,'低级聚神丹','[{\"name\": \"灵动花瓣\", \"数量\": 10}, {\"name\": \"聚神果\", \"数量\": 2}]');
/*!40000 ALTER TABLE `丹方` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `体质`
--

DROP TABLE IF EXISTS `体质`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `体质` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `修炼加成` json DEFAULT NULL,
  `暴击加成` json DEFAULT NULL,
  `爆伤加成` json DEFAULT NULL,
  `防御加成` json DEFAULT NULL,
  `等级` json DEFAULT NULL,
  `exp` json DEFAULT NULL,
  `生命加成` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `体质`
--

LOCK TABLES `体质` WRITE;
/*!40000 ALTER TABLE `体质` DISABLE KEYS */;
INSERT INTO `体质` VALUES (1,'烈焰霸体','低级体质','0.02','0.03','0.02','100','1','1','470'),(2,'龙骨战体','低级体质','0.03','0.04','0.02','100','1','1','470'),(3,'雷神体','低级体质','0.03','0.04','0.04','100','1','1','470'),(4,'火凤体','低级体质','0.03','0.05','0.03','100','1','1','470'),(5,'寒冰霸体','低级体质','0.02','0.04','0.04','100','1','1','470'),(6,'闪电狂体','低级体质','0.03','0.02','0.03','100','1','1','470'),(7,'幻影影体','低级体质','0.03','0.02','0.04','100','1','1','470'),(8,'狂风战体','低级体质','0.03','0.02','0.04','100','1','1','470'),(9,'潜行暗体','低级体质','0.03','0.04','0.02','100','1','1','470'),(10,'爆裂战体','低级体质','0.03','0.03','0.02','100','1','1','470'),(11,'血魔体','低级体质','0.03','0.02','0.03','100','1','1','470'),(12,'灵魂虎体','低级体质','0.03','0.02','0.03','100','1','1','470'),(13,'刀剑无双体','低级体质','0.03','0.03','0.04','100','1','1','470'),(14,'金刚炼体','低级体质','0.03','0.04','0.04','100','1','1','470'),(15,'气吞山河体','低级体质','0.03','0.02','0.03','100','1','1','470'),(16,'神魔炼神体','低级体质','0.03','0.02','0.04','200','1','1','530'),(17,'星辰炼体','中级体质','0.05','0.05','0.06','200','1','1','530'),(18,'光明战体','中级体质','0.05','0.07','0.06','200','1','1','530'),(19,'影之霸体','中级体质','0.05','0.06','0.05','200','1','1','530'),(20,'狂风剑体','中级体质','0.05','0.07','0.06','200','1','1','530'),(21,'雷霆炼体','中级体质','0.05','0.05','0.07','200','1','1','530'),(22,'烈火战体','中级体质','0.05','0.05','0.06','200','1','1','530'),(23,'冰霜凝体','中级体质','0.05','0.07','0.05','200','1','1','530'),(24,'电光闪体','中级体质','0.05','0.06','0.07','200','1','1','530'),(25,'幻影鬼体','中级体质','0.05','0.07','0.05','200','1','1','530'),(26,'血魔战体','中级体质','0.05','0.06','0.07','200','1','1','530'),(27,'灵魂龙体','中级体质','0.05','0.07','0.06','200','1','1','530'),(28,'刀剑无双体','中级体质','0.05','0.06','0.07','200','1','1','530'),(29,'气吞山河体','中级体质','0.05','0.07','0.05','200','1','1','530'),(30,'星辰霸体','高级体质','0.08','0.1','0.09','250','1','1','600'),(31,'光明炼体','高级体质','0.08','0.09','0.08','250','1','1','600'),(32,'影之战体','高级体质','0.08','0.1','0.08','250','1','1','600'),(33,'狂风剑皇体','高级体质','0.08','0.08','0.09','250','1','1','600'),(34,'狂风剑皇体','高级体质','0.08','0.08','0.09','250','1','1','600'),(35,'烈焰战皇体','高级体质','0.08','0.1','0.08','250','1','1','600'),(36,'电光闪耀体','高级体质','0.08','0.09','0.08','250','1','1','600'),(37,'冰霜霸主体','高级体质','0.08','0.08','0.09','250','1','1','600'),(38,'幻影魔帝体','高级体质','0.08','0.08','0.09','250','1','1','600'),(39,'血魔战皇体','高级体质','0.08','0.09','0.08','250','1','1','600'),(40,'灵魂龙帝体','高级体质','0.08','0.09','0.09','250','1','1','600'),(41,'金刚炼皇体','高级体质','0.08','0.08','0.09','250','1','1','600'),(42,'星辰天尊体','天级体质','0.1','0.11','0.12','300','1','1','650'),(43,'刀剑无双体','高级体质','0.08','0.08','0.09','250','1','1','600'),(44,'光明神体','天级体质','0.1','0.12','0.13','300','1','1','650'),(45,'影之战皇体','天级体质','0.1','0.12','0.12','300','1','1','650'),(46,'狂风剑帝体','天级体质','0.1','0.13','0.13','300','1','1','650'),(47,'雷霆战皇体','天级体质','0.1','0.14','0.12','300','1','1','650'),(48,'烈焰战皇体','天级体质','0.1','0.13','0.14','300','1','1','650'),(49,'冰霜霸主体','天级体质','0.1','0.13','0.13','300','1','1','650'),(50,'电光闪耀体','天级体质','0.1','0.12','0.12','300','1','1','650'),(51,'幻影魔帝体','天级体质','0.1','0.11','0.11','300','1','1','650'),(52,'狂风剑帝体','天级体质','0.1','0.13','0.12','300','1','1','650'),(53,'星辰圣尊体','圣级体质','0.15','0.16','0.17','400','1','1','800'),(54,'光明圣体','圣级体质','0.15','0.17','0.17','400','1','1','800'),(55,'狂风圣帝体','圣级体质','0.15','0.18','0.17','400','1','1','800'),(56,'雷霆圣皇体','圣级体质','0.15','0.17','0.17','300','1','1','900'),(57,'烈焰圣皇体','圣级体质','0.15','0.16','0.16','450','1','1','850'),(58,'冰霜圣主体','圣级体质','0.15','0.18','0.18','400','1','1','800'),(59,'电光圣耀体','圣级体质','0.15','0.16','0.17','400','1','1','800'),(60,'星辰神尊体','神级体质','0.2','0.2','0.2','500','1','1','1000'),(61,'神魂无双体','神级体质','0.2','0.21','0.2','400','1','1','1200'),(62,'冰霜神帝体','神级体质','0.2','0.22','0.21','500','1','1','1000'),(63,'闪电神耀体','神级体质','0.2','0.21','0.22','550','1','1','950'),(64,'狂风神帝体','神级体质','0.2','0.23','0.21','500','1','1','1000'),(65,'血魔神皇体','神级体质','0.2','0.22','0.23','500','1','1','1000');
/*!40000 ALTER TABLE `体质` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `体魄境界`
--

DROP TABLE IF EXISTS `体魄境界`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `体魄境界` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `体魄力量` json DEFAULT NULL,
  `攻击加成` json DEFAULT NULL,
  `防御加成` json DEFAULT NULL,
  `暴击加成` json DEFAULT NULL,
  `爆伤加成` json DEFAULT NULL,
  `生命加成` json DEFAULT NULL,
  `闪避加成` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `体魄境界`
--

LOCK TABLES `体魄境界` WRITE;
/*!40000 ALTER TABLE `体魄境界` DISABLE KEYS */;
INSERT INTO `体魄境界` VALUES (1,'体魄一重天','1000','100','100','0.01','0.01','100','0.01'),(2,'体魄二重天','2000','150','150','0.02','0.02','160','0.01'),(3,'体魄三重天','3000','190','190','0.02','0.03','200','0.02'),(4,'体魄六重天','8000','280','280','0.03','0.05','300','0.03'),(5,'体魄七重天','9000','300','300','0.04','0.06','350','0.04'),(6,'体魄八重天','10000','320','320','0.04','0.06','400','0.04'),(7,'体魄五重天','7000','260','260','0.03','0.05','300','0.04'),(8,'体魄九重天','11000','340','340','0.05','0.07','450','0.05'),(9,'体魄十重天','12000','360','360','0.05','0.07','500','0.05'),(10,'体魄四重天','5000','230','230','0.03','0.04','250','0.03');
/*!40000 ALTER TABLE `体魄境界` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `功法列表`
--

DROP TABLE IF EXISTS `功法列表`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `功法列表` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `品级` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `价格` json DEFAULT NULL,
  `介绍` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `all_功效` json DEFAULT NULL,
  `功效` json DEFAULT NULL,
  `zhandou` json DEFAULT NULL,
  `万界堂` json DEFAULT NULL,
  `能否消耗` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `功法列表`
--

LOCK TABLES `功法列表` WRITE;
/*!40000 ALTER TABLE `功法列表` DISABLE KEYS */;
INSERT INTO `功法列表` VALUES (1,'初级呼吸吐纳法','功法','低级','10000','初级呼吸吐纳法','[\"修炼加成\"]','{\"修炼加成\": 0.02, \"攻击加成\": 0, \"暴击加成\": 0, \"爆伤加成\": 0, \"生命加成\": 0, \"闪避加成\": 0, \"防御加成\": 0}',NULL,'1','\"是\"'),(2,'中级呼吸吐纳法','功法','中级','20000','中级呼吸吐纳法','[\"修炼加成\"]','{\"修炼加成\": 0.05, \"攻击加成\": 0, \"暴击加成\": 0, \"爆伤加成\": 0, \"生命加成\": 0, \"闪避加成\": 0, \"防御加成\": 0}',NULL,'1','\"是\"'),(3,'高级呼吸吐纳法','功法','高级','35000','高级呼吸吐纳法','[\"修炼加成\"]','{\"修炼加成\": 0.08, \"攻击加成\": 0, \"暴击加成\": 0, \"爆伤加成\": 0, \"生命加成\": 0, \"闪避加成\": 0, \"防御加成\": 0}',NULL,'1','\"是\"'),(4,'闪电五连鞭','功法','中级','30000','闪电五连鞭,具有闪电之威','[\"攻击加成\", \"暴击加成\"]','{\"修炼加成\": 0, \"攻击加成\": 100, \"暴击加成\": 0.05, \"爆伤加成\": 0, \"生命加成\": 0, \"闪避加成\": 0, \"防御加成\": 0}','\"发出马宝国的成名技闪电五连鞭,此技赋有雷电之威\"','0','\"是\"'),(5,'咏春拳','功法','中级','50000','咏春拳','[\"攻击加成\", \"暴击加成\", \"爆伤加成\"]','{\"修炼加成\": 0, \"攻击加成\": 150, \"暴击加成\": 0.05, \"爆伤加成\": 0.1, \"生命加成\": 0, \"闪避加成\": 0, \"防御加成\": 0}','\"使出咏春拳,企图迅速将敌人制服\"','0','\"是\"'),(6,'截拳道','功法','中级','50000','截拳道','[\"攻击加成\", \"暴击加成\", \"爆伤加成\"]','{\"修炼加成\": 0, \"攻击加成\": 150, \"暴击加成\": 0.05, \"爆伤加成\": 0.1, \"生命加成\": 0, \"闪避加成\": 0, \"防御加成\": 0}','\"使出截拳道\"','0','\"是\"'),(7,'半步崩拳','功法','高级','1000000','半步崩拳','[\"攻击加成\", \"暴击加成\", \"爆伤加成\"]','{\"修炼加成\": 0, \"攻击加成\": 300, \"暴击加成\": 0.1, \"爆伤加成\": 0.15, \"生命加成\": 0, \"闪避加成\": 0, \"防御加成\": 0}','\"使出半步崩拳,向前迈出半步，力气凝聚与拳中，向敌人轰出\"','0','\"是\"'),(8,'天地一刀斩','功法','圣级','10000000','天地一刀斩','[\"攻击加成\", \"暴击加成\", \"爆伤加成\"]','{\"修炼加成\": 0, \"攻击加成\": 800, \"暴击加成\": 0.2, \"爆伤加成\": 0.25, \"生命加成\": 0, \"闪避加成\": 0, \"防御加成\": 0}','\"使出天地一刀斩,聚天地之力于武器，向前轰出\"','0','\"是\"'),(9,'双节棍','功法','中级','50000','双节棍','[\"攻击加成\", \"暴击加成\", \"爆伤加成\"]','{\"修炼加成\": 0, \"攻击加成\": 150, \"暴击加成\": 0.05, \"爆伤加成\": 0.1, \"生命加成\": 0, \"闪避加成\": 0, \"防御加成\": 0}','\"使出双节棍\"','0','\"是\"'),(10,'灵气斩','功法','圣级','2500000','灵气斩','[\"攻击加成\", \"暴击加成\", \"爆伤加成\"]','{\"修炼加成\": 0, \"攻击加成\": 800, \"暴击加成\": 0.2, \"爆伤加成\": 0.25, \"生命加成\": 0, \"闪避加成\": 0, \"防御加成\": 0}','\"使出灵气斩,蓝色剑气向敌人斩去，减少敌人灵气(战斗中不可恢复)\"','0','\"是\"'),(11,'寸拳','功法','中级','50000','寸拳','[\"攻击加成\", \"暴击加成\", \"爆伤加成\"]','{\"修炼加成\": 0, \"攻击加成\": 160, \"暴击加成\": 0.07, \"爆伤加成\": 0.1, \"生命加成\": 0, \"闪避加成\": 0, \"防御加成\": 0}','\"使出寸拳\"','0','\"是\"'),(12,'灵气斩','功法','圣级','2500000','灵气斩','[\"攻击加成\", \"暴击加成\", \"爆伤加成\"]','{\"修炼加成\": 0, \"攻击加成\": 800, \"暴击加成\": 0.2, \"爆伤加成\": 0.25, \"生命加成\": 0, \"闪避加成\": 0, \"防御加成\": 0}','\"使出灵气斩,蓝色剑气向敌人斩去，减少敌人灵气(战斗中不可恢复)\"','0','\"是\"'),(13,'霜寒掌','功法','中级','1800000','霜寒掌','[\"攻击加成\", \"暴击加成\", \"爆伤加成\"]','{\"修炼加成\": 0, \"攻击加成\": 600, \"暴击加成\": 0.1, \"爆伤加成\": 0.08, \"生命加成\": 0, \"闪避加成\": 0, \"防御加成\": 0}','\"施展霜寒掌, 寒气凝聚成掌, 打向对方\"','1','\"是\"'),(14,'烈焰步','功法','高级','2000000','烈焰步','[\"攻击加成\", \"暴击加成\", \"爆伤加成\", \"闪避加成\"]','{\"修炼加成\": 0, \"攻击加成\": 700, \"暴击加成\": 0.2, \"爆伤加成\": 0.1, \"生命加成\": 0, \"闪避加成\": 0.04, \"防御加成\": 0}','\"运用烈焰步, 身形如焰, 快速穿梭战场, 敌人陷入烈焰之中\"','1','\"是\"'),(15,'风影剑法','功法','圣级','1200000','风影剑法','[\"攻击加成\", \"暴击加成\", \"爆伤加成\"]','{\"修炼加成\": 0, \"攻击加成\": 500, \"暴击加成\": 0.1, \"爆伤加成\": 0.11, \"生命加成\": 0, \"闪避加成\": 0, \"防御加成\": 0}','\"发挥风影剑法, 剑招似风, 快速划过敌人, 产生锋利的风刃\"','1','\"是\"'),(16,'雷霆拳法','功法','圣级','3500000','雷霆拳法','[\"攻击加成\", \"暴击加成\", \"爆伤加成\"]','{\"修炼加成\": 0, \"攻击加成\": 850, \"暴击加成\": 0.12, \"爆伤加成\": 0.09, \"生命加成\": 0, \"闪避加成\": 0, \"防御加成\": 0}','\"施展雷霆拳法, 拳势如雷, 击中敌人时对地方造成高额伤害\"','0','\"是\"'),(17,'幻影步法','功法','高级','2500000','灵气斩','[\"攻击加成\", \"暴击加成\", \"爆伤加成\"]','{\"修炼加成\": 0, \"攻击加成\": 100, \"暴击加成\": 0.09, \"爆伤加成\": 0.05, \"生命加成\": 0, \"闪避加成\": 0.2, \"防御加成\": 0}','\"运用幻影步法, 身形如影, 敌人难以捕捉到真实位置\"','1','\"是\"'),(18,'地煞拳','功法','中级','2500000','灵气斩','[\"攻击加成\", \"暴击加成\", \"爆伤加成\"]','{\"修炼加成\": 0, \"攻击加成\": 650, \"暴击加成\": 0.1, \"爆伤加成\": 0.18, \"生命加成\": 0, \"闪避加成\": 0, \"防御加成\": 0}','\"运用地煞拳, 拳力激荡, 可引发地面剧烈震动, 造成地裂伤害\"','1','\"是\"'),(19,'影月剑术','功法','高级','2900000','灵气斩','[\"攻击加成\", \"暴击加成\", \"爆伤加成\"]','{\"修炼加成\": 0, \"攻击加成\": 850, \"暴击加成\": 0.15, \"爆伤加成\": 0.2, \"生命加成\": 0, \"闪避加成\": 0, \"防御加成\": 0}','\"发动影月剑术, 剑光如影.对敌方造成攻击\"','0','\"是\"');
/*!40000 ALTER TABLE `功法列表` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `妖兽地点`
--

DROP TABLE IF EXISTS `妖兽地点`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `妖兽地点` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `妖兽` json DEFAULT NULL,
  `time` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `妖兽地点`
--

LOCK TABLES `妖兽地点` WRITE;
/*!40000 ALTER TABLE `妖兽地点` DISABLE KEYS */;
INSERT INTO `妖兽地点` VALUES (1,'北方之林','[{\"name\": \"猪兽\", \"数量\": 0}, {\"name\": \"兔妖\", \"数量\": 0}, {\"name\": \"牛妖\", \"数量\": 0}]','0');
/*!40000 ALTER TABLE `妖兽地点` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `武者境界`
--

DROP TABLE IF EXISTS `武者境界`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `武者境界` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `灵气` json DEFAULT NULL,
  `攻击加成` json DEFAULT NULL,
  `防御加成` json DEFAULT NULL,
  `暴击加成` json DEFAULT NULL,
  `爆伤加成` json DEFAULT NULL,
  `生命加成` json DEFAULT NULL,
  `闪避加成` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `武者境界`
--

LOCK TABLES `武者境界` WRITE;
/*!40000 ALTER TABLE `武者境界` DISABLE KEYS */;
INSERT INTO `武者境界` VALUES (1,'F阶低级武者','1000','100','100','0.01','0.01','100','0.01'),(2,'F阶中级武者','2000','150','150','0.02','0.02','160','0.01'),(3,'F阶高级武者','3000','190','190','0.02','0.03','200','0.02'),(4,'E阶低级武者','5000','230','230','0.03','0.04','250','0.03'),(5,'E阶中级武者','8000','280','280','0.03','0.05','300','0.03'),(6,'E阶低级武者','7000','260','260','0.03','0.05','300','0.04'),(7,'E阶高级武者','5000','230','230','0.03','0.04','250','0.03'),(8,'D阶低级武者','10000','300','300','0.04','0.06','350','0.04'),(9,'D阶中级武者','20000','400','400','0.08','0.06','550','0.04'),(10,'D阶高级武者','35000','600','600','0.08','0.1','650','0.04'),(11,'C阶低级武者','50000','800','800','0.1','0.12','800','0.05'),(12,'C阶中级武者','70000','1000','1000','0.12','0.14','1000','0.06'),(13,'C阶高级武者','90000','1200','1200','0.14','0.16','1200','0.07'),(14,'B阶低级武者','120000','1500','1500','0.16','0.18','1500','0.08'),(15,'B阶中级武者','150000','1800','1800','0.18','0.2','1800','0.09'),(16,'B阶高级武者','180000','2100','2100','0.2','0.22','2100','0.1'),(17,'A阶低级武者','220000','2500','2500','0.22','0.24','2500','0.11'),(18,'A阶高级武者','300000','3500','3500','0.26','0.28','3500','0.13'),(19,'A阶中级武者','260000','3000','3000','0.24','0.26','3000','0.12');
/*!40000 ALTER TABLE `武者境界` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `灵器列表`
--

DROP TABLE IF EXISTS `灵器列表`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `灵器列表` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `品级` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `攻击加成` json DEFAULT NULL,
  `防御加成` json DEFAULT NULL,
  `生命加成` json DEFAULT NULL,
  `暴击加成` json DEFAULT NULL,
  `爆伤加成` json DEFAULT NULL,
  `闪避加成` json DEFAULT NULL,
  `等级` json DEFAULT NULL,
  `exp` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `灵器列表`
--

LOCK TABLES `灵器列表` WRITE;
/*!40000 ALTER TABLE `灵器列表` DISABLE KEYS */;
INSERT INTO `灵器列表` VALUES (1,'破碎之盾','低级灵器','5','20','15','0.01','0.01','0.03','1','0'),(2,'破刀','低级灵器','10','10','10','0.01','0.01','0.01','1','0'),(3,'炽热战斧','高级灵器','40','25','30','0.05','0.06','0.04','1','0'),(4,'寒冰法杖','中级灵器','30','10','25','0.02','0.03','0.02','1','0'),(5,'雷霆之锤','高级灵器','45','20','35','0.05','0.06','0.03','1','0'),(6,'幽影匕首','中级灵器','35','15','20','0.02','0.03','0.05','1','0'),(7,'风暴长弓','高级灵器','50','10','25','0.05','0.06','0.02','1','0'),(8,'翡翠项链','低级灵器','5','5','30','0.01','0.01','0.01','1','0'),(9,'炎龙戒指','中级灵器','20','10','20','0.05','0.06','0.03','1','0'),(10,'月光披风','高级灵器','15','30','40','0.05','0.06','0.04','1','0'),(11,'星辰头盔','中级灵器','10','25','30','0.02','0.03','0.02','1','0'),(12,'狂战胸甲','高级灵器','25','40','50','0.05','0.06','0.01','1','0'),(13,'灵动战靴','中级灵器','15','20','25','0.02','0.03','0.06','1','0'),(14,'炽天使之剑','高级灵器','60','20','30','0.05','0.06','0.03','1','0'),(15,'暗影魔杖','高级灵器','55','15','35','0.05','0.06','0.04','1','0'),(16,'寒冰法杖','中级灵器','40','10','25','0.02','0.03','0.02','1','0'),(17,'炎魔之弓','高级灵器','65','15','20','0.05','0.06','0.03','1','0'),(18,'狼牙棒','低级灵器','15','5','10','0.01','0.01','0.01','1','0'),(19,'碧水剑','中级灵器','35','10','15','0.02','0.03','0.02','1','0'),(20,'破空斧','高级灵器','50','25','30','0.05','0.06','0.03','1','0'),(21,'噬魂刃','中级灵器','45','15','20','0.02','0.03','0.04','1','0'),(22,'天雷锤','低级灵器','20','10','15','0.01','0.01','0.01','1','0'),(23,'绿波扇','中级灵器','30','20','25','0.02','0.03','0.03','1','0'),(24,'破碎之刃','高级灵器','55','20','35','0.05','0.06','0.05','1','0'),(25,'翡翠戒指','低级灵器','5','5','20','0.01','0.01','0.01','1','0'),(26,'龙鳞护腕','中级灵器','15','25','30','0.02','0.03','0.02','1','0'),(27,'炽炎披风','高级灵器','20','35','40','0.05','0.06','0.04','1','0'),(28,'幽冥头盔','中级灵器','10','20','25','0.02','0.03','0.03','1','0'),(29,'狮心胸甲','高级灵器','25','45','50','0.02','0.03','0.02','1','0'),(30,'风行战靴','中级灵器','15','15','20','0.02','0.03','0.05','1','0'),(31,'炼狱项链','高级灵器','30','10','40','0.05','0.06','0.03','1','0'),(32,'光辉耳环','中级灵器','20','10','30','0.02','0.03','0.02','1','0'),(33,'暗夜指环','低级灵器','10','5','15','0.01','0.01','0.01','1','0'),(34,'破晓之弓','高级灵器','70','10','20','0.05','0.06','0.03','1','0'),(35,'狂风法杖','中级灵器','45','15','25','0.02','0.03','0.04','1','0'),(36,'炼金术士之杖','低级灵器','20','5','10','0.01','0.01','0.01','1','0'),(37,'碎骨锤','中级灵器','40','20','30','0.02','0.03','0.03','1','0'),(38,'破军长枪','高级灵器','60','25','35','0.05','0.06','0.02','1','0'),(39,'破魔刀','低级灵器','25','10','15','0.01','0.01','0.01','1','0'),(40,'无尽之刃','高级灵器','75','30','40','0.05','0.06','0.05','1','0'),(41,'狂暴之戟','中级灵器','50','25','35','0.02','0.03','0.03','1','0'),(42,'破灭之杖','低级灵器','30','10','20','0.01','0.01','0.01','1','0'),(43,'神秘权杖','高级灵器','65','20','45','0.03','0.05','0.04','1','0'),(44,'梦幻浩然长弓','帝兵','650','600','500','0.1','0.13','0.04','1','0');
/*!40000 ALTER TABLE `灵器列表` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `灵魂境界`
--

DROP TABLE IF EXISTS `灵魂境界`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `灵魂境界` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `灵魂力量` json DEFAULT NULL,
  `攻击加成` json DEFAULT NULL,
  `防御加成` json DEFAULT NULL,
  `暴击加成` json DEFAULT NULL,
  `爆伤加成` json DEFAULT NULL,
  `生命加成` json DEFAULT NULL,
  `闪避加成` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `灵魂境界`
--

LOCK TABLES `灵魂境界` WRITE;
/*!40000 ALTER TABLE `灵魂境界` DISABLE KEYS */;
INSERT INTO `灵魂境界` VALUES (1,'灵魂境界二重天','3000','200','200','0.02','0.02','200','0.02'),(2,'灵魂境界一重天','1000','100','100','0.01','0.01','100','0.01'),(3,'灵魂境界五重天','15000','1600','1600','0.05','0.05','500','0.05'),(4,'灵魂境界四重天','10000','800','800','0.04','0.04','400','0.04'),(5,'灵魂境界三重天','6000','400','400','0.03','0.03','300','0.03'),(6,'灵魂境界六重天','21000','3200','3200','0.06','0.06','600','0.06'),(7,'灵魂境界七重天','28000','6400','6400','0.07','0.07','700','0.07'),(8,'灵魂境界八重天','36000','12800','12800','0.08','0.08','800','0.08'),(9,'灵魂境界九重天','45000','25600','25600','0.09','0.09','900','0.09'),(10,'灵魂境界十重天','55000','51200','51200','0.1','0.1','1000','0.1');
/*!40000 ALTER TABLE `灵魂境界` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `猎杀妖兽地点`
--

DROP TABLE IF EXISTS `猎杀妖兽地点`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `猎杀妖兽地点` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `掉落物` json DEFAULT NULL,
  `攻击加成` json DEFAULT NULL,
  `防御加成` json DEFAULT NULL,
  `暴击加成` json DEFAULT NULL,
  `爆伤加成` json DEFAULT NULL,
  `生命加成` json DEFAULT NULL,
  `闪避加成` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `猎杀妖兽地点`
--

LOCK TABLES `猎杀妖兽地点` WRITE;
/*!40000 ALTER TABLE `猎杀妖兽地点` DISABLE KEYS */;
INSERT INTO `猎杀妖兽地点` VALUES (1,'金钱豹','[{\"name\": \"金色的毛发\", \"概率\": 0.5}, {\"name\": \"豹子的脏器\", \"概率\": 0.3}]','1000','1000','0.05','0.04','1000','0.05');
/*!40000 ALTER TABLE `猎杀妖兽地点` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `道具列表`
--

DROP TABLE IF EXISTS `道具列表`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `道具列表` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `品级` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `价格` json DEFAULT NULL,
  `介绍` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `能否消耗` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `万界堂` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `道具列表`
--

LOCK TABLES `道具列表` WRITE;
/*!40000 ALTER TABLE `道具列表` DISABLE KEYS */;
INSERT INTO `道具列表` VALUES (1,'金色的毛发','道具','低级','50','金色的毛发','否','1'),(2,'豹子的脏器','道具','低级','100','豹子的脏器','否','1'),(3,'低级强灵草','道具','低级','100','低级强灵草','否','1'),(4,'低级强灵丹','道具','低级','10000','低级强灵草','是','0'),(5,'低级灵器经验石','道具','低级','10000','低级灵器经验石','是','1'),(6,'高级灵器经验石','道具','低级','28000','高级灵器经验石','是','1'),(7,'灵动花瓣','道具','低级','20000','灵动花瓣','否','1'),(8,'聚神果','道具','低级','58000','灵动花瓣','否','1'),(9,'中级灵器经验石','道具','低级','18000','中级灵器经验石','是','1');
/*!40000 ALTER TABLE `道具列表` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'wuzhe'
--

--
-- Dumping routines for database 'wuzhe'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-31 19:25:27
